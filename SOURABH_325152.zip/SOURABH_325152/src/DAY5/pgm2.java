package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm2 {

	private static XSSFWorkbook wb;

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		
				
				
				try {
					File f=new File("C:\\Users\\sourabh.negi\\Desktop\\sheet1.xlsx");
					FileInputStream fis=new FileInputStream(f);
					wb = new XSSFWorkbook(fis);
					XSSFSheet sh=wb.getSheet("Sheet1");
					XSSFRow r=sh.getRow(0);
					XSSFCell c=r.getCell(0);
					XSSFRow r1=sh.getRow(1);
					XSSFCell c1=r1.getCell(0);
					String s = c.getStringCellValue();
					String t = c1.getStringCellValue();
					System.out.println(s+" "+t);
					
				/*	//   write
				
					XSSFCell c2=r.createCell(1); // creating blank cell
					c2.setCellValue("negi");
					String a=c2.getStringCellValue();
					System.out.println("new value: "+a);
					*/
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}

		

	}


