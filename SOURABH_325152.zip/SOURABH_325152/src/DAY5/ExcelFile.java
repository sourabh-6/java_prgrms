package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelFile {


	public student read_excel(int row)
	{
	student s=new student();
		try {
			
			File f=new File("C:\\Users\\sourabh.negi\\Desktop\\sheet2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			@SuppressWarnings("resource")
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			XSSFRow r1=sh.getRow(row);
			XSSFCell c0=r1.getCell(0);
			s.rollno=(int) c0.getNumericCellValue();
			
			XSSFCell c1=r1.getCell(1);
			s.name= c1.getStringCellValue();
			
			XSSFCell c2=r1.getCell(2);
			s.java=(int)c2.getNumericCellValue();
			
			XSSFCell c3=r1.getCell(3);
			s.selenium=(int)c3.getNumericCellValue();

			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return s;
		
	}
	
	public void write_excel(student s,int row)
	{
		try {
			
		File f=new File("C:\\Users\\sourabh.negi\\Desktop\\sheet2.xlsx");
		FileInputStream fis=new FileInputStream(f);
		@SuppressWarnings("resource")
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("Sheet1");
		XSSFRow r=sh.getRow(row);
		XSSFCell c=r.createCell(4);
		c.setCellValue(s.average());
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		
		catch(FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}
}