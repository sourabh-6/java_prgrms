package DAY9;

public class test_bank extends bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bank b = new bank();
		bank h = new hdfc(); // h=-hdfc
		bank ic = new icici(); // i=icici

		h.get_roi(8.7f);
		ic.get_roi(9.5f);
	}

}