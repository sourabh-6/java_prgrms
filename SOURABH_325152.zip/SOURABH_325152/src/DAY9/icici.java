package DAY9;

public class icici extends bank{
public void get_roi(float f)
{
	System.out.println("roi of  icici bank is: "+f);}
}
