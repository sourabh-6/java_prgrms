package DAY6;

import java.util.ArrayList;

public class arraylist {

	ArrayList<student> a=new ArrayList<student>();
	public void create_al()
	{
		student s1=new student("Ramesh",101,80,90);
		student s2=new student("shyam",102,85,95);
		a.add(s1);
		a.add(s2);
	}
	public void display_al()
	{
		for(student s:a)
		{
			System.out.println("Name: "+s.name+" Rollno:"+s.rollno+" Selenium:"+s.sel+" Java:"+s.jav+" Average:"+s.average());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arraylist al=new arraylist();
		al.create_al();
		al.display_al();
		
	}

}
