package DAY8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelFile {
	// ArrayList<Passenger> student=new ArrayList<Passenger>();
	int j = 1;//j=i

	public Passenger read_excel(int r, Passenger p)

	{
		try {

			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\Assign.xlsx");
			FileInputStream fis = new FileInputStream(f);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");

			XSSFRow r1 = sh.getRow(r);

			XSSFCell c0 = r1.getCell(0);
			p.Sno = (int) c0.getNumericCellValue();

			XSSFCell c1 = r1.getCell(1);
			p.name = c1.getStringCellValue();

			XSSFCell c2 = r1.getCell(2);
			p.from = c2.getStringCellValue();

			XSSFCell c3 = r1.getCell(3);
			p.to = c3.getStringCellValue();

			XSSFCell c4 = r1.getCell(4);
			p.rate = (int) c4.getNumericCellValue();

			XSSFCell c5 = r1.getCell(5);
			p.seat = (int) c5.getNumericCellValue();

		}

		catch (FileNotFoundException e1) {
			// TODO: handle exception
			e1.printStackTrace();

		}

		catch (IOException e) {
			e.printStackTrace();
		}

		return p;

	}

	public void write_excel(int r, Passenger p) {
		try {
			j = 1;
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\Assign.xlsx");
			FileInputStream fis = new FileInputStream(f);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");

			// Student s=new Student();
			XSSFRow j = sh.getRow(r);
			XSSFCell c = j.createCell(6);
			c.setCellValue(p.total);

			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);

		}

		catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		catch (IOException e) {
			e.printStackTrace();
		}

	}

}
