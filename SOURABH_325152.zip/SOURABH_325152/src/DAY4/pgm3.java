package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	        String line = "The world is full of strangers";
	        String w = line.substring(0,line.indexOf(" "));
	       int i=line.length();
	     //  System.out.println();
	       while(i>1)
	       {
	    	   System.out.println(w);
	    	   line=line.substring(line.indexOf(" ")+1)+" ";
	    	   w=line.substring(0,line.indexOf( " "));
	    	   i--;
	    	 
	    	
	       }
	       
}
	}