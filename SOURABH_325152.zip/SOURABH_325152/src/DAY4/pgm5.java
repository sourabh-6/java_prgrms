package DAY4;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
cal c=new cal();
int a=c.add(10, 20);
System.out.println(a);
float b=c.add(10.3f,20.6f);
System.out.println(b);
	}

}
