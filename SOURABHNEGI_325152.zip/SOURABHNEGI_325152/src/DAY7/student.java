package DAY7;

public class student {

	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	
	public void average()
	{
		 avg=(java+selenium)/2;
		 
	}
	
	
}
