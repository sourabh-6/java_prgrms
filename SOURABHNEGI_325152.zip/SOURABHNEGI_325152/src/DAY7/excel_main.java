package DAY7;

import java.util.ArrayList;

public class excel_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		excl_operations ex= new excl_operations();
		ArrayList<student> std_list=new ArrayList<student>();
		std_list=ex.read_excel();
		
		ex.write_excel(std_list);

	}

}
