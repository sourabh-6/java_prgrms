package DAY11;

public class test_bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
bank b;
b=new hdfc();
System.out.println("bank rate of hdfc: "+b.get_roi());
	
b=new icici();
System.out.println("bank rate of icici: "+b.get_roi());}

}
