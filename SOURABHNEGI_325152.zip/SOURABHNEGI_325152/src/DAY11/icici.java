package DAY11;

public class icici extends bank {
	
float get_roi()
{
	return 9.5f;
	}
}
