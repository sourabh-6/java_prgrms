package DAY9;

public class pgm1main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
pgm1 p=new pgm1();
p.setAccount_bal(10000000);
p.setAccount_no(123456);
System.out.println("account no:"+p.getAccount_no()+"  account bal:"+p.getAccount_bal());
	}

}
