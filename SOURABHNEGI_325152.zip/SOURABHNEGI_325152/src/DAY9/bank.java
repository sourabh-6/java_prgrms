package DAY9;

public class bank {
public void get_roi(float i) {
		System.out.println(+i);
	}
}
