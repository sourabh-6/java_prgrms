package assignment;

public class owls extends birds{
	int hear;
	String eye;
	
	public void eats() {
		System.out.println("owls eats squirells and insects");
	}
	
	public void found() {
		System.out.println("owls are found all region except polar ice");
	}
	public void sound() {
		System.out.println("owl sound called hoot");
	}
	
	public owls(int hear, String eye) {
		// TODO Auto-generated constructor stub
		this.hear=hear;
		this.eye=eye;
		eats();
		found();
		sound();
	}


	public void display() {
		System.out.println("Name: "+this.name +"\nNo of legs: " +this.nol + "\nSkin color: "+ this.color   
							+ "\nGender: " + this.gender + "\nAge: " + this.age );
		
		System.out.println("owl can hear upto: "+ this.hear + "\nsee upto: " + this.eye+"\n");
	}

}
