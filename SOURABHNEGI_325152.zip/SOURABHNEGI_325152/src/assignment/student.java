package assignment;

public class student {
	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	
	public float average()
	{
		  return avg=(java+selenium)/2;
		 
	}
	
	public student(int rollno,int java,int selenium,String name)	//constructor
	{
		
		this.rollno=rollno;;
		this.java=java;
		this.selenium=selenium;
		this.name=name;
	//	avg=this.avg;
		average();
		
	}
}
