package assignment;

public class student4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
student s[]=new student[3];
student s1=new student(101,90,80,"sourabh");
student s2=new student(102,95,85,"abhay");
student s3=new student(101,90,70,"jasjeet");
s[0]=s1;
s[1]=s2;
s[2]=s3;
for(int i=0;i<3;i++)
{
	if(s[i].avg>65)
		{
		System.out.println("roll no:"+s[i].rollno+"name: "+s[i].name+"java marks:"+s[i].java
				+"selenium marks"+s[i].selenium);
				
		}}
	}

}
