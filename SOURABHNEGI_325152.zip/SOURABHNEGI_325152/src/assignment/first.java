package assignment;

import java.util.ArrayList;


public class first {

	public static void main(String[] args) {
		//int n=20;
		ArrayList<Integer> str = new ArrayList<Integer>();
		for(int i=11;i<=29;i++)
		{
			if(i%2==0)
			{
				str.add(i);
			}
		}
	
	//	for(Integer i:str)
			System.out.println("   "+str);
		
	}

}
