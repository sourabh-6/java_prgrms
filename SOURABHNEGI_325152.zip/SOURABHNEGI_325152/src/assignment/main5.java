package assignment;

public class main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		excel_op e=new excel_op();
		e.read_excel();
		e.write_excel();
		

	}

}
