package assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//import DAY7.student;
//import DAY8.Passenger;

public class excel_op 
{
	
	ArrayList<data5> std_al=new ArrayList<data5>();
	int pid,per_rate,unit,price;
	String name,grade;
	public void read_excel() {
		
				
	try {
		File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\5.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		//int first_row=sh.getFirstRowNum();
		//int last_row=sh.getLastRowNum();
		//int nor=last_row-first_row;
		for(int i=1;i<=3;i++)
		{
		
		XSSFRow r=sh.getRow(i);
		XSSFCell c=r.getCell(0);
		pid=(int)c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		name=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		per_rate=(int)c2.getNumericCellValue();
		
		XSSFCell c3=r.getCell(3);
		unit=(int)c3.getNumericCellValue();
		
		data5 d=new data5(pid,name,per_rate,unit); 
		std_al.add(d);
		
		
		
		}
	} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	
	//return std_al;

	}
	
	
	

	public void write_excel() {
		try {
			//int j = 1;
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\5.xlsx");
			FileInputStream fis = new FileInputStream(f);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			int row=1;
			
			
			for(data5 d:std_al) {
				
				XSSFRow r=sh.getRow(row);
				
				XSSFCell c4=r.createCell(4);
				c4.setCellValue(d.price);
				
				XSSFCell c5=r.createCell(5);
				c5.setCellValue(d.grade);
				
			   row++;

			 
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);

		}  }

		catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		catch (IOException e) {
			e.printStackTrace();
		}
}
	}
