package assignment;

public class third {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] arr=new int[]{23,44,84,37,91,18};
int  s=0;
	for(int i=0;i<arr.length;i++)
		{
		if(i%2==0)
		{
			if(arr[i]%2!=0)
			{
		s=s+arr[i];		
			}
		}
		
		
		}
	System.out.println(s);
	}

}
