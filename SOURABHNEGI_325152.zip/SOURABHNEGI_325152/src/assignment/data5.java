package assignment;

public class data5 {

	int pid,per_rate,unit,price;
	String name;
	String grade;
	public data5(int pid, String name, int per_rate, int unit) {
		 this.pid=pid;
		 this.name=name;
		 this.per_rate=per_rate;
		 this.unit=unit;
		 price();
		 grade();
	}
	public void price()
	{
		price=per_rate*unit;
		//return price;
	}
	public void grade()
	{
		if(price<25000)
			grade="A";
		else
			grade="B";
	}
	
}
