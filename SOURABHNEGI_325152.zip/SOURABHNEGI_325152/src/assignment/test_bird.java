package assignment;

public class test_bird {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		parrots p1=new parrots("red","green");
		
		p1.age=5;
		p1.food="eats fruit,flower, buds,seeds";         
		p1.gender="male";
		p1.name="raju";
		p1.nol=2;
		p1.walks();
		p1.fly();
		p1.display();
		
		parrots p2=new parrots("yellow","green");
		p2.age=10;
		p2.food="eats flower, buds,seeds";         
		p2.gender="female";
		p2.name="sheela";
		p2.nol=2;
		p2.walks();
		p2.fly();
		p2.display();

		
		parrots p3=new parrots("orange","green");
		p3.age=15;
		p3.food="eats fruit,flower,seeds";         
		p3.gender="male";
		p3.name="champu";
		p3.nol=2;
		p3.walks();
		p3.fly();
		p3.display();

		
		
		
		owls o1=new owls(7,"strong night vision");
		owls o2=new owls(6,"medium night vision");
		o1.age=10;
		o1.color="brown";
		o1.gender="male";
		o1.name="abhay";
		o1.nol=2;
		o1.walks();
		o1.fly();
		o1.display();

		
		
        o2.age=15;
		o2.color="grey";
		o2.gender="female";
		o2.name="shruti";
		o2.nol=2;
		o2.walks();
		o2.fly();
		o2.display();

	}

}
