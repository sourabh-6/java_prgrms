package assignment;

public class parrots extends birds{

	String eye_c;
	String body_c;
	public void inteligent() {
		System.out.println("parrots are intelligent");
	}
	

	public void feet() {
		System.out.println("parrots eats with feet");
	}
	
	public void live() {
		System.out.println("parrots live for max 80 years");
	}
	
	public parrots(String eye_c, String body_c) {
		// TODO Auto-generated constructor stub
		this.eye_c=eye_c;
		this.body_c=body_c;
		inteligent();
		feet();
		live();
	}


	public void display() {
		System.out.println("No of legs: " +this.nol  + "\nFood: " + this.food + "\nName: "+this.name 
							+ "\nGender: " + this.gender + "\nAge: " + this.age );
		
		System.out.println("eye colour of parrot: "+ this.eye_c+"\n" + " body colour : " + this.body_c+"\n");
	}

	
}
