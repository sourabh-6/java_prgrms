package assignment;

import java.util.ArrayList;

public class vowel {
	
	
 public static int vowelCount(String str)
		  {
		 int count=0;
		 char word[]=str.toCharArray();
		 //int i;
		 for(char ch:word)
		 if(ch=='a'|| ch=='e' || ch=='i' ||  ch=='o' || ch=='u')
		         count++;
		 
		return count;
		  }

		  public static ArrayList<String> get_each_word(String str)
		  {
		 String[] s=str.split("[ ,]");  //space and ','
		 ArrayList<String> words =new ArrayList<String>();
		 
		 for(String word:s)
		 words.add(word);
		 
		 return words;
		 
		 }
		 
		 
		 
		 
		  public static ArrayList<String> count_vowels(ArrayList<String> v)
		  {
		 
		 ArrayList<String> words =new ArrayList<String>();
		 for(String s:v)
		 if(vowelCount(s)>2)
		 words.add(s);
		 return words;
		 
		  }
		 
		 

		public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="I have learnt loops, opps concept, inheritence, exception handling, arraylist and string handling";
		ArrayList<String> words,finalWords;
		words=get_each_word(str);
		finalWords=count_vowels(words);
		for(String s:finalWords)
		System.out.println(s);


		}

		}
 
