package assignment;

import java.util.ArrayList;



public class vowel {
	
	
	
	public static String[] word(String str)
	{
		String[] s=str.split("\\W+");
		return s;
	}


	public static void main(String[] args) {
		 
String line="i have learnt loops,oops concept,inheritance,exception handling, arraylist and string bhandling";
String[] words;
words=word(line);

ArrayList<String> str=new ArrayList<String>();
for(String word:words)
	str.add(word);
	
System.out.println(str);
//countvowel(str);
}
// public static ArrayList<String> count_vowels(ArrayList<String> v)
	 
		
		
	}
