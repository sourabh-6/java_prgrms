package assignment;

public class second {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] arr=new int[4];
int c=0;
int i=100;

int s;
while(c<4)
{
	int r=0;
	int a=i;
while(a>0)
{
s=a%10;
r=r+s*s*s;
a=a/10;
}
if(r==i)
{
	arr[c]=i;
c++;
i++;
	}
else
	i++;
	}
for( i=0;i<arr.length;i++)
{
System.out.println(arr[i]);
}	}

}
