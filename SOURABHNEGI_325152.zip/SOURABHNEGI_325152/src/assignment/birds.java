package assignment;

public class birds {
	int nol;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	
	public void walks()
	{
		System.out.println("it can walk");
		
	}
	public void fly() {
		System.out.println("it can fly");
	}
	public void display()
	{
		System.out.println("No of the legs : "+this.nol+"\n Skin Color : "+this.color+"\nFood "+this.food+"\nName : "+this.name);
		
}
}
