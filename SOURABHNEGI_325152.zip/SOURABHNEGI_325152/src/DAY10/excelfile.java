package DAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelfile {
	
	
	int cid,rid,unit_price,not;
	String cname,from,to;
	table4 t;

	int i; 
	
	 public void read_excel_table1(int rid)
		{
		 
		
        		
	 
		 try {
				
			    File f=new File("C:\\Users\\sourabh.negi\\Desktop\\t1.xlsx");
				FileInputStream fis=new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				
				 
		 	  for(i=1;i<=2;i++) {
			    
		 		  int row_number;
									
				XSSFRow r=sh.getRow(i);
				
				XSSFCell c0=r.getCell(0);
				
				row_number =(int)c0.getNumericCellValue();    //row
				
				if(rid==row_number)
				{
					    XSSFCell c1=r.getCell(1);
						from=c1.getStringCellValue();
						
						XSSFCell c2=r.getCell(2);
						to=c2.getStringCellValue();
						
						XSSFCell c3=r.getCell(3);
						unit_price=(int) c3.getNumericCellValue();
				}
					
				}
						 
			}
			
			
		catch(FileNotFoundException e) {
			e.printStackTrace();
			}
			
			catch(IOException e) {
				e.printStackTrace();
			}
			
			 
			//return p;
		}
	 
	 
	 
	 
	 
	 
	 
	 public void read_excel_table2(int cid)
		{
		 
		int customer_id;
     		
	 
		 try {
				
			    File f=new File("C:\\Users\\sourabh.negi\\Desktop\\t2.xlsx");
				FileInputStream fis=new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				
				 
		 	  for(i=1;i<=2;i++) {
			    
									
				XSSFRow r=sh.getRow(i);
				
				XSSFCell c0=r.getCell(0);
				customer_id =(int)c0.getNumericCellValue(); //int
				
				
				
				if(customer_id==cid) {
				
			    XSSFCell c1=r.getCell(1);
				cname=c1.getStringCellValue();
				 
				 
			}
				}
		 }
			
			
		catch(FileNotFoundException e) {
			e.printStackTrace();
			}
			
			catch(IOException e) {
				e.printStackTrace();
			}
			
			 
			 
		}
	 
	 
	 
	 
	 
	 
	 public table4 read_excel_table3(int row)
		{
		 
		
     		
	 
		 try {
				
			    File f=new File("C:\\Users\\sourabh.negi\\Desktop\\t3.xlsx");
				FileInputStream fis=new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				
				 
		 	  
			 //  for(i=1;i<=2;i++) {  // it is used when we are working with arraylist
				   
				  // TableFour t=new TableFour
									
				XSSFRow r1=sh.getRow(row);
				
				XSSFCell c0=r1.getCell(0);
				cid =(int)c0.getNumericCellValue();  
				
				XSSFCell c1=r1.getCell(1);
				rid =(int)c1.getNumericCellValue();
				
				XSSFCell c2=r1.getCell(2);
				not =(int)c2.getNumericCellValue();
				
				read_excel_table1(rid);
				read_excel_table2(cid);
				
				t=new table4(cid,cname,from,to,unit_price,not);
				t.total();
				
			//   }
			    
				 
			}
			
			
		catch(FileNotFoundException e) {
			e.printStackTrace();
			}
			
			catch(IOException e) {
				e.printStackTrace();
			}
			
			 
			return t;
		}
	 
	 
	 
	  
	 											// write excel fn
		
		
		public void write_excel_table4(int row,table4 t)
		{
             try {
				 
				File f=new File("C:\\Users\\sourabh.negi\\Desktop\\t4.xlsx");
				FileInputStream fis=new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				
			
				XSSFRow r=sh.createRow(row);
				
				XSSFCell c0=r.createCell(0);
				c0.setCellValue(t.cid);
				
				XSSFCell c1=r.createCell(1);
				c1.setCellValue(t.cname);
				
				XSSFCell c2=r.createCell(2);
				c2.setCellValue(t.from);
				
				XSSFCell c3=r.createCell(3);
				c3.setCellValue(t.to);
				
				XSSFCell c4=r.createCell(4);
				c4.setCellValue(t.unit_price);
				
				XSSFCell c5=r.createCell(5);
				c5.setCellValue(t.not);
				
				XSSFCell c6=r.createCell(6);
				c6.setCellValue(t.total);
				
				System.out.println(t.total);
				
				
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
				 
				 
				 }
             
             
		catch(FileNotFoundException e1) {
			e1.printStackTrace();
			}
			
			catch(IOException e) {
				e.printStackTrace();
			} 
		
		}
}
