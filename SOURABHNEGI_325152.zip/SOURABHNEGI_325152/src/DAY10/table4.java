package DAY10;

public class table4 {

	
	
						// basically we create this class for writing values in t4 
	
	int cid,unit_price,not,total;
	String cname,from,to;
	
	public void total()
	{
		total=not*unit_price;
		
	}
	
	public table4(int cid,String cname,String from,String to,int unit_price,int not)
	{
		this.cid=cid;
		this.unit_price=unit_price;
		this.not=not;
		this.cname=cname;
		this.from=from;
		this.to=to;
		// total();
	}
	
}
