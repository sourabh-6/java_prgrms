package DAY10;

public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		table4 t; // by this object we will move around.
		int i;
		excelfile ex=new excelfile();
		for(i=1;i<=2;i++)
		{    
		   t=ex.read_excel_table3(i);
	       ex.write_excel_table4(i,t);
	      // ex.write_excel_table4(2,t);
				 
		} 
	}
	
}
