package practice;

public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern(5);

}

	private static void pattern(int i) {
		// TODO Auto-generated method stub
		for(int r=1;r<=i;r++)
		{
			for(int s=i-1;s>0;s--)
		{System.out.print(+s);
		
		}
			for(int c=1;c<=i;c++)
			{
				System.out.print("1");
			}
		}
		System.out.println("\n");
	}
}