package practice;

public class chartostring {
	

		   public static void main(String args[]) {
		      char[] helloArray = { 'h', 'e', 'l', 'l', 'o', '.' };
		      String helloString = new String(helloArray);  
		      System.out.println( helloString );
		 String s="";
		      for(int i=0;i<helloArray.length;i++) {
		    	  s+=helloArray[i];
		      }
		      
		      System.out.println("After conversion "+s);
		      
		      
		   // string to char
//		      
//		      String s = "GeeksforGeeks"; 
//		        char[] gfg = s.toCharArray(); 
//		        for (int i = 0; i < gfg.length; i++) { 
//		            System.out.println(gfg[i]); 
//		      
//		   }
		}
}

