package DAY8;

public class Excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int j;
ExcelFile ex=new ExcelFile();
for(j=1;j<=4;j++)
{
	Passenger p=new Passenger();
	p=ex.read_excel(j,p);
	p.calculate_rate();
	ex.write_excel(j,p);
	}
	}

}
