package DAY8;

public class Passenger {

	int Sno, rate, seat, total;
	String name, from, to;

	public void calculate_rate() {
		total = seat * rate;
	}

}
