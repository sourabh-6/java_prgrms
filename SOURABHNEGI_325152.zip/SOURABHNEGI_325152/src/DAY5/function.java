package DAY5;

public class function {

}
