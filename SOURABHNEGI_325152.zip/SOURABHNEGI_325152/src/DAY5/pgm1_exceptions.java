package DAY5;

public class pgm1_exceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

try {
	int num[]= {1,2,3};
	int b=num[2];
	System.out.println(b);
	int a=10,b1=0,c;
	c=a/b1;
	System.out.println(c);
	}
catch (ArithmeticException e) {
System.out.println("ArithmeticException inside catch block ");
System.out.println("outside catch block");// TODO: handle exception
}
}
}