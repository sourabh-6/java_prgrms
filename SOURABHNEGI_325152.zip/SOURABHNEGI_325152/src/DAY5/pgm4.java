package DAY5;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class pgm4 {

	private static XSSFWorkbook wb;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	File f=new File("C:\\Users\\sourabh.negi\\Desktop\\sheet1.xlsx");
	FileInputStream fis=new FileInputStream(f);
	wb = new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	//XSSFRow r=sh.getRow(0);
	//XSSFCell c=r.getCell(0);
	XSSFRow r=sh.createRow(3);
XSSFCell c=r.createCell(0);
String s=c.getStringCellValue();
	System.out.println(s);
	c.setCellValue("SELenium");
	FileOutputStream fos=new FileOutputStream (f);
			wb.write(fos);
}
catch (FileNotFoundException e) {
	// TODO: handle exception
	e.printStackTrace();
}
catch (IOException e) {
	e.printStackTrace();
	// TODO: handle exception
}
	}

}
