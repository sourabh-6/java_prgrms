package DAY5;


public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int i;
			ExcelFile ex=new ExcelFile();
			for(i=1;i<=2;i++)
			{
			
				student s=ex.read_excel(i);
				s.average();
				ex.write_excel(s,i);
	}

		
}
}