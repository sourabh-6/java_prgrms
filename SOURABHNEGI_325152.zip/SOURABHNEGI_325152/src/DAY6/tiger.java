package DAY6;

public class tiger extends animal {

	int lenghtofteeth;
	int lenghtofclaw;
	
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void hunts() {
		System.out.println("Tiger hunts its prey");
	}
	
		
		
	public tiger(int lott, int loc) {
		// TODO Auto-generated constructor stub
		this.lenghtofteeth=lott;
		this.lenghtofclaw=loc;
		roar();
		climb();
		hunts();
	}


	public void display() {
		System.out.println("No of legs: " +this.nol + "\nSkin color: "+ this.color + "\nFood: " + this.food + "\nName: "+this.name 
							+ "\nGender: " + this.gender + "\nAge: " + this.age );
		
		System.out.println("Length of teeth : "+ this.lenghtofteeth + " Length of claws : " + this.lenghtofclaw);
	}


}
