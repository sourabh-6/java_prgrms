package DAY6;

public class pgm1_for {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str[]= {"noida","global logic","delhi"};
for(String s:str)
{
	System.out.println(s);
	}
Integer i[]= {1,2,3};
for(Integer nt :i)
{
	System.out.println(nt);
	}
	}

}
