package DAY6;

import java.util.ArrayList;


public class pgm2_arraylist {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		ArrayList<String> str_al=new ArrayList<String>();
		str_al.add("asf");
		str_al.add("rakesh");
		str_al.add("HImanshu");
		str_al.add("Suresh");
		System.out.println(str_al);
	//    ANOTHER WAY OF FETCHING THE DATA FROMM ARRAYLIST
		/*
		 * for(String s:str_al)
		 
		{
			System.out.println(s);
		}
		*/
str_al.add("negi");
System.out.println(str_al);
str_al.add(1, "rock");
	str_al.get(1);	
	System.out.println(str_al);
	str_al.remove(0);
	System.out.println(str_al);
	int a=str_al.size();
	System.out.println("size: "+a);}
}
