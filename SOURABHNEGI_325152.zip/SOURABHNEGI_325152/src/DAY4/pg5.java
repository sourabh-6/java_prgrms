package DAY4;

public class pg5 {
public int add(int x,int y)
{
	int z=x+y;
	return z;
	}
public float add(float x, float y)
{
return 1.0f;
}
public float add(int x,int y,float z)
{
	float f=x+y+z;
	return f;}
}
