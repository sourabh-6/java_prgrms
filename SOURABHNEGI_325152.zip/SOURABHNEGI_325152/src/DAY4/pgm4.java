package DAY4;

public class pgm4 {

		// TODO Auto-generated method stub
	 int a; 
	    int b; 
	      
	    // Parameterized constructor 
	    pgm4(int a, int b) 
	    { 
	        this.a = a; 
	        this.b = b; 
	    } 
	  
	    void display() 
	    { 
	        //Displaying value of variables a and b 
	        System.out.println("a = " + a + " and b = " + b); 
	    } 
	  
	    public static void main(String[] args) 
	    { 
	        pgm4 object = new pgm4(10, 20); 
	        object.display(); 
	    } 
	}


