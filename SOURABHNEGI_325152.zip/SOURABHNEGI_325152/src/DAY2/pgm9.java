package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=5;
		int i=5,j=4;
while(s>0)
{   int x=i*j;
	System.out.println(""+i+"*"+j+"="+x);
	i++;j=j+2;
	s--;
	}
System.out.println(""+i+" "+j);
		}
	}




