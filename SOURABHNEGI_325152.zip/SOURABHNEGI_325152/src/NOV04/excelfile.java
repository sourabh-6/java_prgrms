package NOV04;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelfile {
	public void read_excel(int row)
	{float phy,che,avg;
	String name;
	try {

	    File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\marks.xlsx");
		FileInputStream fis=new FileInputStream(f);
		@SuppressWarnings("resource")
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");

		XSSFRow r = sh.getRow(row);

		XSSFCell c0 = r.getCell(0);
		name = c0.getStringCellValue();

		XSSFCell c1 = r.getCell(1);
		phy = (float) c1.getNumericCellValue();

		XSSFCell c2 = r.getCell(2);
		che = (float) c2.getNumericCellValue();

		avg=(phy+che)/2;
		find_excel(name,avg);
		//wb.close();   to save memory leak
	}
	catch (Exception e) {
		System.out.println(e);
	}
		// TODO: handle exception
	}

	private void find_excel(String name, float avg) {
		// TODO Auto-generated method stub
String s;
try {


    File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\marks.xlsx");
	FileInputStream fis=new FileInputStream(f);
	@SuppressWarnings("resource")
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet2");
	
	for(int i=1;i<=3;i++)
	{
		XSSFRow r= sh.getRow(i);
		XSSFCell c0=r.getCell(0);
		s=c0.getStringCellValue();
		if(s.equals(name))
		{
			write_excel(i,avg);
		}
	}
}
catch (Exception e) {
	System.out.println(e);
	// TODO: handle exception
}
	}

	private void write_excel(int row, float avg) {
		// TODO Auto-generated method stub
		try {
			File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\marks.xlsx");
			FileInputStream fis=new FileInputStream(f);
			@SuppressWarnings("resource")
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r=sh.getRow(row);
			XSSFCell c1=r.createCell(1);
			c1.setCellValue(avg);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
	}

}
