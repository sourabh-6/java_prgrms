package NOV04;


public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
excelfile ex=new excelfile();
for(int i=1;i<=3;i++)
{ex.read_excel(i);
	}
	}

}
