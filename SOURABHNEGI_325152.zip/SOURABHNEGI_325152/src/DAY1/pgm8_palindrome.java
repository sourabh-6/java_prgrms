package DAY1;

import java.util.Scanner;

public class pgm8_palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	        int num = 121, rev = 0, r, o;
	        o = num;
	        // reversed integer is stored in variable 
	        while( num != 0 )
	        {
	            r = num % 10;
	            rev = rev * 10 + r;
	            num  /= 10;
	        }
	        // palindrome if orignalInteger and reversedInteger are equal
	        if (o == rev)
	            System.out.println(o + " is a palindrome.");
	        else
	            System.out.println(o + " is not a palindrome.");
	    }

}
