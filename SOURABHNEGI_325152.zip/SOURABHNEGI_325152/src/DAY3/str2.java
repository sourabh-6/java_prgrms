package DAY3;

public class str2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1=" I am learning java";
int c=0;
int l=s1.length();
for(int i=0;i<l;i++)

if(s1.charAt(i)==' ')
{c++;
}
{if(s1.charAt(0)==' ')
{c--;
}
if(s1.charAt(l-1)==' ')
{
	c--;}
}
System.out.println(c);
}

}
