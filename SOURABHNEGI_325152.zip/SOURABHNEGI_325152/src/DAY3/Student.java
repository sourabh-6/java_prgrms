package DAY3;

public class Student {

	public int rollno;
	
public String name;
public int m1,m2;
public float avg;
public void average()
{
	avg=  ((m1+m2)/2);   // direct assigning the value not returning
	}

public void display()
{
	System.out.println("roll no: "+rollno);
	System.out.println("name:"+name);
	System.out.println("marks1: "+m1);
	System.out.println("marks2: "+m2);
	System.out.println("average:"+avg);
	System.out.println("\n");}

}
