package DAY3;



public class pgm4 {

	public static void main(String[] args) {
		
		int marks[][]= {{77,95,83},{65,92,79}};
		for(int r=0;r<=1;r++)
		{
			for(int c=0;c<=2;c++)
			{
				System.out.print(marks[r][c]+" ");
			}
			System.out.println("\n");
		}

	}

}
