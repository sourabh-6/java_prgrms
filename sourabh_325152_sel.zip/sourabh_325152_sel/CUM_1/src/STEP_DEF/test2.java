package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
WebDriver dr;
@When("^User enters invalid login data and  clicks ok button$")
public void user_enters_invalid_login_data_and_clicks_ok_button() throws Throwable {
dr=test1.dr;
dr.findElement(By.xpath("//input[@class='email']")).sendKeys("sourabhnegi356@gmail.com");	
dr.findElement(By.xpath("//input[@class='password']")).sendKeys("P@ssword61");	
dr.findElement(By.xpath("//input[@value='Log in']")).click();

}

@Then("^Home page is not displayed$")
public void home_page_is_not_displayed() throws Throwable {
System.out.println("login unsuccessful");
SoftAssert sa=new SoftAssert();
sa.assertEquals(sa,"sourabhnegi356@gmail.com");
sa.assertAll();
}
}


