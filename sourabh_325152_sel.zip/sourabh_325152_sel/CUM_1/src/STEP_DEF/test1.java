package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
public static WebDriver dr;

	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	 System.out.println("Login page is displayed");  
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
	
	@When("^User enters login data and  clicks ok button$")
	public void user_enters_login_data_and_clicks_ok_button() throws Throwable {
		dr.findElement(By.xpath("//input[@class='email']")).sendKeys("sourabhnegi356@gmail.com");	
		dr.findElement(By.xpath("//input[@class='password']")).sendKeys("P@ssword6");	
		dr.findElement(By.xpath("//input[@value='Log in']")).click();

		
	}

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
		System.out.println("Home page is displayed");
		String ar=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		String er="sourabhnegi356@gmail.com";
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(ar,er);
		sa.assertAll();
	 
	}
	
}
