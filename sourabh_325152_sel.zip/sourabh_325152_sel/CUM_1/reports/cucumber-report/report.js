$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "User enters login data and  clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 8516671800,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_data_and_clicks_ok_button()"
});
formatter.result({
  "duration": 1861860300,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 70501800,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Login with invalid data",
  "description": "",
  "id": "aut-login;login-with-invalid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "User enters invalid login data and  clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 7902593500,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_invalid_login_data_and_clicks_ok_button()"
});
formatter.result({
  "duration": 1021283400,
  "status": "passed"
});
formatter.match({
  "location": "test2.home_page_is_not_displayed()"
});
formatter.result({
  "duration": 3330400,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [sourabhnegi356@gmail.com] but found [org.testng.asserts.SoftAssert@21680803]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test2.home_page_is_not_displayed(test2.java:26)\r\n\tat ✽.Then Home page is not displayed(a.feature:13)\r\n",
  "status": "failed"
});
});