package SDAY5;

import java.io.File;    // for one row checking
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm {

	 static ArrayList<data> d_al = new ArrayList<data>();
	public static data d = new data();

	public static void readexcel() {

		try {
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\selenium.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r = sh.getRow(1);
			XSSFCell c = r.getCell(0);
			d.uid = c.getStringCellValue();
			XSSFCell c1 = r.getCell(1);
			d.password = c1.getStringCellValue();
			XSSFCell c2 = r.getCell(2);
			d.exp_res = c2.getStringCellValue();
			XSSFCell c3 = r.getCell(3);
			d.exp_em1 = c3.getStringCellValue();
			XSSFCell c4 = r.getCell(4);
			d.exp_em2 = c4.getStringCellValue();
			System.out.println("uid::" + d.uid + "  " + d.password + " " + d.exp_em1 + " " + d.exp_em2);
			d_al.add(d);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// return d;
	}

	public static data login(data d) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d.password);
		dr.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"))
				.click();
		boolean f = dr.getTitle().contains("Login");
		// System.out.println(f);
		if (!f) {
			d.act_res = "success";
			System.out.println("login successful");
		} else {
			d.act_res = "failure";
			d.act_em1 = dr.findElement(By.xpath(
					"/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span"))
					.getText();
			d.act_em2 = dr.findElement(By.xpath(
					"/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li"))
					.getText();
		}
		if (d.exp_res.equals(d.act_res)) {
			if (d.exp_em1.equals(d.act_em1) && d.exp_em2.equals(d.act_em2)) {
				d.testresult = "pass";
			} else {
				d.testresult = "fail";
			}
		}

		return d;
	}

	public static void writeexcel(data d) {
		// TODO Auto-generated method stub
		try {
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\selenium.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r = sh.getRow(1);
			XSSFCell c = r.createCell(5);
			c.setCellValue(d.act_res);
			System.out.println((d.act_res));
			XSSFCell c1 = r.createCell(6);
			c1.setCellValue(d.act_em1);
			XSSFCell c2 = r.createCell(7);
			c2.setCellValue(d.act_em2);
			XSSFCell c3 = r.createCell(8);
			c3.setCellValue(d.testresult);

			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		readexcel();
		login(d);
		writeexcel(d);

	}

}
