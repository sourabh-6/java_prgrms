package SDAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgmm {
	static ArrayList<data> d_al = new ArrayList<data>();

public static data d1;
public static data d2;// global declaration of data objects. so that they can be acess from any function
	public static data readexcel(int i) {
	data d=new data();  // initializing obj of data type
		try {
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\selenium.xlsx");
			FileInputStream fis = new FileInputStream(f);
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r = sh.getRow(i);
			XSSFCell c = r.getCell(0);
			d.uid = c.getStringCellValue();
			XSSFCell c1 = r.getCell(1);
			d.password = c1.getStringCellValue();
			XSSFCell c2 = r.getCell(2);
			d.exp_res = c2.getStringCellValue();
			if (d.exp_res.compareTo("success") == 0) {

			} else {
				XSSFCell c3 = r.getCell(3);
				d.exp_em1 = c3.getStringCellValue();

				XSSFCell c4 = r.getCell(4);
				d.exp_em2 = c4.getStringCellValue();
			}

			System.out.println("uid::" + d.uid + "  " + d.password + " ");
			d_al.add(d);     // object of data d is adding in array list
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	return d;
		
	}

	public static data login(data d) // we are passing data d to login wbecause we require value to login
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d.password);
		dr.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"))
				.click();
		boolean f = dr.getTitle().contains("Login");
		// System.out.println(f);
		if (!f) {
			d.act_res = "success";
			System.out.println("login successful");

		} else {

			d.act_res = "failure";
			d.act_em1 = dr.findElement(By.xpath(
					"/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span"))
					.getText();
			d.act_em2 = dr.findElement(By.xpath(
					"/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li"))
					.getText();
		}
		if (d.exp_res.compareTo(d.act_res) != 0) {
			if (d.exp_res.equals(d.act_res)) {
				if (d.exp_em1.equals(d.act_em1) && d.exp_em2.equals(d.act_em2)) {
					
					d.testresult = "fail";
				} //else {
					//d.testresult = "fail";
				//}
			}
		} 
		else
			d.testresult = "pass";
		
		return d;
		
	}

	public static void writeexcel(data d,int i) // here we are passing data and row to which changes are to be made
	{
		// TODO Auto-generated method stub
		try {
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\selenium.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r = sh.getRow(i);
			XSSFCell c = r.createCell(5);
			c.setCellValue(d.act_res);
			System.out.println((d.act_res));

			if (d.exp_res.compareTo(d.act_res) == 0) {

				XSSFCell c3 = r.createCell(8);
				c3.setCellValue(d.testresult);
				
			}				
		if(d.exp_res.compareTo("failure")==0)
		{
				XSSFCell c1 = r.createCell(6);
				c1.setCellValue(d.act_em1);
				XSSFCell c2 = r.createCell(7);
				c2.setCellValue(d.act_em2);
		}	

	

			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);	// for writing on excel sheet
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 2; i++) {
			//data d=new data(); 
			//data d;
			d1=readexcel(i); // no need to create another object of data type basically both these obj point to same data
			d2=login(d1);
			writeexcel(d2,i);
		}
	}

}
