package SDAY5;

import org.openqa.selenium.WebDriver; 			// handling multiple windows
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.naukri.com/");
		String hnd=dr.getWindowHandle();
		System.out.println(hnd);
		for(String handle: dr.getWindowHandles())
		{
			dr.switchTo().window(handle);
			String title=dr.getTitle();
			System.out.println(title);
			
			try {
				Thread.sleep(3000);
				
			}
			catch (InterruptedException e) {
				e.printStackTrace();
				// TODO: handle exception
			}
			
			
		}	}

}




// success   http://demowebshop.tricentis.com/


//user incorrect  
//pasww incorrect   http://demowebshop.tricentis.com/login