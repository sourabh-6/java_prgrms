package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {

	
	static WebDriver dr;
	public cart_page()
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
		
		
	}
	

	public static String cart() {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
		String s2=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		System.out.println("s2: "+s2);
		return s2;
	}
}
