package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class login_page {

	WebDriver dr;
	public login_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
		
	}
	
	public void do_login(String email,String password)
	{
	dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys(email);	
	dr.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);	
	dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();

	
	}
	
}
