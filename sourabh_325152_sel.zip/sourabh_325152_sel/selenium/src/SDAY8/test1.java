package SDAY8;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class test1 {
	public static String a;
	public static String b;
	
//public static final String String = null;
	login_page lp;
	home_page hp;
	WebDriver dr;
    cart_page cp;
  
	@BeforeClass
public void bc()
{
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp=new login_page(dr);
		hp=new home_page(dr);

}
	
	@Test
  public void t1() {
  
	lp.do_login("standard_user","secret_sauce");
	hp.add_to_cart(1);
	hp.get_prod_name(1);
	a="Sauce Labs Backpack";
	System.out.println("a: "+a);
	b=cart_page.cart();
	//hp.verify(a,b);
	SoftAssert sa=new SoftAssert();
	
	sa.assertEquals(a,b);
	
	System.out.println("Sourabh");
}
}