package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class home_page {

	WebDriver dr;
	String base_xp="//div[@class='inventory_item'][";
	By xname,xprice,xbtn;
	public home_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr,this);
	}

	public String get_prod_name(int n)
	{
		xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_price']");
	//	String pprice=dr.findElement(xprice).getText();
	//	System.out.println("pprice : "+pprice);
		String s1=dr.findElement(By.xpath("//a[@id='item_4_title_link']//div[@class='inventory_item_name']")).getText();
		System.out.println("s1: "+s1);
		//return pprice;
		return s1;
	}
	public void add_to_cart(int n)
	{
		xbtn=By.xpath(base_xp+n+"]//button");
		
		dr.findElement(xbtn).click();
	}
	//t	 		making 						separate 					webpage 
	/*public String click_cart()
	{
		dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
		String s2=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		System.out.println("s2: "+s2);
		return s2;
	}*/
	
	public void verify(String a,String b)
	{
		System.out.println("i am in verify block");
		System.out.println("in verify fn s1:"+a+"  and s2: "+b);
		if(a.equals(b))
		{
			System.out.println("verified");
		}
		else
		{
			System.out.println("not verified");
		}
	}
}
