package SDAY9;

import java.io.IOException;

import org.apache.log4j.Logger;

public class HFW extends excel_read {

	static Logger log;
	static keyword_sh d = new keyword_sh();
	static tc_selection td = new tc_selection();
	static String filename = "";

	public static void main(String a[]) throws IOException {

		String id, ch, testdata = null;
		int i, j, k = 0;
		for (i = 1; i <= 3; i++) {
			// td=excel read read_sheet1
			// td = read_sheet1(i); // td is from TC SELECTION SHEET
			System.out.println(td.flag);
			if (td.flag.equals("Y")) {
				for (j = 1; j < 20; j++) // traverse keyword sheet
				{
					d = excel_read.read_kw_sh(j); // d is from keyword sheet
					System.out.println("d.TC_ID : " + d.TC_ID);
					if (d.TC_ID.equals(td.tcid)) {
						System.out.println("YES");
						break;
					} else
						continue;
				}

				get_test_data(td.test_data_sh, 2, 2);
				// display_testdata();

				for (login_test_data data : td_al) {
					for (k = j; k <= ((j + td.no_steps) - 1); k++) {
						// if()
					}
				}

			}
		}
	}

}
