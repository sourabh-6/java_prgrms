package SDAY9;

public class keyword_sh {
public String TC_ID;
public String step_no;
public String keyWord;
public String XPath;
public String Test_Data;
}
