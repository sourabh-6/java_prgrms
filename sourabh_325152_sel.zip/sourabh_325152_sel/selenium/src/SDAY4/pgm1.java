package SDAY4;


//P@ssword6
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.google.com");
		dr.get("http://demowebshop.tricentis.com/");
		String ti="Demo Web Shop";
		String title=dr.getTitle();
		if(title.compareTo(title)==0)
			System.out.println("verified title");
		System.out.println("titile: "+title);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	
	String title1=dr.getTitle();
	System.out.println("titile: "+title1);
	

dr.findElement(By.id("FirstName")).sendKeys("sourabh");
dr.findElement(By.id("LirstName")).sendKeys("negi");
dr.findElement(By.id("Email")).sendKeys("sourabhnegi006@gmail.com");
dr.findElement(By.id("Pasword")).sendKeys("pass123$");
dr.findElement(By.id("ConfirmPassword")).sendKeys("pass123$");}
	
	
	
	
	
	// /html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]     register ur 
}
