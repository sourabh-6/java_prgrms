package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class auto_login {
	String uid,pwd,exp_res,act_res,test_res;


public  void login()
{
	
	try {
		File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\Book1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		@SuppressWarnings("resource")
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("Sheet1");
		XSSFRow r1=sh.getRow(1);
		
		
		XSSFCell c1=r1.getCell(0);
	uid=c1.getStringCellValue();
	

	XSSFCell c2=r1.getCell(1);
	pwd =c2.getStringCellValue();
	
	XSSFCell c3=r1.getCell(2);
	exp_res =c3.getStringCellValue();
	System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/login");
	
	dr.findElement(By.id("Email")).sendKeys(uid);
	dr.findElement(By.id("Password")).sendKeys(pwd);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	
	
	String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	System.out.println(s);
	if(s.compareTo("sourabhnegi356@gmail.com")==0)
	{System.out.println("login successfulllllllllllllllllllllllllllll");
		
	}
	
	else
	{
		System.out.println("login uuuuuuuuuuuuuuuunsucessfulllllllllllllll");
	}
	
// write
	XSSFRow row=sh.getRow(1);
	XSSFCell c=row.createCell(3);

	
	
	}catch(Exception e)
	{
		e.printStackTrace();
	}}
public static void main(String[] args)
{
	
auto_login a=new auto_login();

a.login();
}
}
