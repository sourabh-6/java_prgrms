package SDAY3;

public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
auto_login a=new auto_login();
//login_data d=new login_data();

	}

}
