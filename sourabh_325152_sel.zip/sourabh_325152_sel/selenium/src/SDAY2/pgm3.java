package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();

		//String url="https://www.w3schools.com/html/html_tables.asp";
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		
		
		String s=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[1]")).getText();
		System.out.println(s);
		String s1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[4]/td[1]")).getText();
		System.out.println(s1);
	// 4th one
		System.out.println();
for(int r=2;r<=7;r++)
{
	for(int c=1;c<=3;c++)
		{//
		String w=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["   +r    +"]/td["     +c  +"]")).getText();
		System.out.print(w+"      ");
		}
	System.out.println();}
		//String s2=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[3]/th[1]")).getText();
		//System.out.println(s2);
	}

}
