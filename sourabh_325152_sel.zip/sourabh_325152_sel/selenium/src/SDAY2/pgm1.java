package SDAY2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		//  select date month and  year
		
		WebElement w=dr.findElement(By.id("day"));
		Select s=new Select(w);
		s.selectByVisibleText("10");
		
		
		WebElement w1=dr.findElement(By.id("month"));
		Select s1=new Select(w1);
		s1.selectByVisibleText("Jan");
		
		WebElement w2=dr.findElement(By.id("year"));
		Select s2=new Select(w2);
		s2.selectByVisibleText("2019");
		
		
	}

}
