package SDAY2;

import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.ClickAction;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		// how to print title
		
		String title=dr.getTitle();
		System.out.println("titile: "+title);
		
		// select male radio buttton here findelements is not element because for sex there are multiple values
		//so we will put it into one array.
		
	List rb=dr.findElements(By.name("sex"));
	((WebElement)rb.get(1)).click();
	//(WebElement)rb.get(1)).Click();
		
	}

}