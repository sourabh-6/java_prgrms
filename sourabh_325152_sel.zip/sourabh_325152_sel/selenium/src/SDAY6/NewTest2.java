package SDAY6;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest2 {
	@AfterMethod
	public void AM()
	{
		System.out.println("AM");
	}
	
	//@BeforeMethod
	@BeforeMethod
	public void BM()
	{
		System.out.println("BM");	
	}
  
  public void c() {
  System.out.println("in test c");
  }
  
  @Test
  public void b() {
	  System.out.println("in test b"); 
  }
  
  @Test
  public void a() {
	  System.out.println("in test a");
  }
  
}
