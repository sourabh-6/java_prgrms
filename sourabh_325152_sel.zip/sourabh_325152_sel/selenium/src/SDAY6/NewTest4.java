package SDAY6;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	@BeforeClass
	  public void BC() {
		System.out.println("i came to the cricket stadium");
	  }
	
	@AfterClass
	  public void AC() {
		System.out.println("now i am back home");
	  }
	@BeforeMethod
	public void BM()
	{
		System.out.println("Hello");	
	}
	
	@AfterMethod
	public void AM()
	{
		System.out.println("BYE");	
	}
	@Test
	  public void a() {
		  System.out.println("i met mr dhoni");
	  }
	  

  @Test
  public void b() {
  System.out.println("i had my lunch with mr virat kohli");
  }
  
  @Test
  public void c() {
  System.out.println("i took apic with mr rohit sharma");
  }
}
