package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm5 {
	static ArrayList<data> t_al = new ArrayList<data>();
	public static ArrayList<data> tdata;
	public static data t2data;

	public static ArrayList<data> readexcel() {
		for (int i = 1; i <= 2; i++) {
			data d = new data();
			try {
				File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\selenium.xlsx");
				FileInputStream fis = new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				XSSFRow r = sh.getRow(i);
				XSSFCell c = r.getCell(0);
				d.uid = c.getStringCellValue();
				XSSFCell c1 = r.getCell(1);
				d.password = c1.getStringCellValue();
				XSSFCell c2 = r.getCell(2);
				d.exp_res = c2.getStringCellValue();
				if (d.exp_res.compareTo("success") == 0) {

				} else {
					XSSFCell c3 = r.getCell(3);
					d.exp_em1 = c3.getStringCellValue();

					XSSFCell c4 = r.getCell(4);
					d.exp_em2 = c4.getStringCellValue();
				}

				System.out.println("uid::" + d.uid + "  " + d.password + " ");
				t_al.add(d);
			} catch (FileNotFoundException e) {
				// TODO: handle exception
				e.printStackTrace();
			} catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}

		return t_al;
	}

	// login

	public static ArrayList<data> login(ArrayList<data> tdata2, int i) {

		t2data = tdata2.get(i - 1);

		System.setProperty("webdriver.chrome.driver", "chromedriver_78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(t2data.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(t2data.password);
		dr.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"))
				.click();
		boolean f = dr.getTitle().contains("Login");
		// System.out.println(f);
		if (!f) {
			t2data.act_res = "success";
			System.out.println("login successful");
			if (t2data.exp_res.equals(t2data.act_res)) {
				t2data.testresult = "pass";
			}

			 else {
			 t2data.testresult = "fail";
			 }
		} else {

			t2data.act_res = "failure";
			t2data.act_em1 = dr.findElement(By.xpath(
					"/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span"))
					.getText();
			t2data.act_em2 = dr.findElement(By.xpath(
					"/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li"))
					.getText();
		}
		if (t2data.act_res.equals("failure")) {
			
			if (t2data.exp_res.equals(t2data.act_res)) {
				if (t2data.exp_em1.equals(t2data.act_em1) && t2data.exp_em2.equals(t2data.act_em2)) {

					t2data.testresult = "pass";
				} else {
					t2data.testresult = "fail";
				}
			}
		} 

		t_al.add(t2data);
		return t_al;
	}

	public static void writeexcel(ArrayList<data> t) // d is t and new
	{

		for (int i = 1; i <= 2; i++) {
			t2data = t.get(i - 1);
			try {
				File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\selenium.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				XSSFRow r = sh.getRow(i);
				XSSFCell c = r.createCell(5);
				c.setCellValue(t2data.act_res);
				System.out.println((t2data.act_res));

				if (t2data.exp_res.equals("failure")) {
					XSSFCell c1 = r.createCell(6);
					c1.setCellValue(t2data.act_em1);
					XSSFCell c2 = r.createCell(7);
					c2.setCellValue(t2data.act_em2);

				}

				XSSFCell c3 = r.createCell(8);
				c3.setCellValue(t2data.testresult);

				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
			} catch (FileNotFoundException e) {
				// TODO: handle exception
				e.printStackTrace();

			} catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

}
