package SDAY6;

import java.util.ArrayList;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NewTest5 {
	pgm5 p=new pgm5();
	ArrayList<data>al_t;
	ArrayList<data>al_t1;
	@BeforeClass
	public void t1()
	{
		al_t=new ArrayList<data>();
		al_t=p.readexcel();
	}
  @Test
  public void t2() {
	  p.login(al_t,1);
	  System.out.println("1");
  }
  
  @Test
  public void t3() {
	  p.login(al_t,2);
	  System.out.println("2");
  }
  
  @AfterClass
  public void t4() {
	  p.writeexcel(al_t);
  }
}
