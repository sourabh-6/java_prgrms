package SDAY6;

import org.testng.annotations.Test;

public class NewTest3 {
	pgm1 p=new pgm1();
data t;
data t1;
  @Test
  public void test() {
	  t=new data();
	  t1=new data();
	  t.uid="sourabhnegi356@gmail.com";
	  t.password="P@ssword6";
	  t.exp_res="success";
	t1= p. login(t);
	System.out.println("actualresult"+t.act_res+" "+" testresult"+t1.testresult+" ");
  }
}
