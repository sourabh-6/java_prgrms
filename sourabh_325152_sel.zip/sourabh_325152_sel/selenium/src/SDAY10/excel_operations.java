package SDAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import SDAY9.keyword_sh;
import SDAY9.login_test_data;
import SDAY9.tc_selection;

public class excel_operations {

	
	public static String filename="C:\\Users\\sourabh.negi\\Desktop\\excel\\registerdemo.xlsx";
	public static String kw_sheet="KEYWORD10";
	public static String tc_sheet="TC_SELECTION_SH10";
	public static XSSFSheet kw_sh_obj,td_sh_obj,tc_sh_obj;
		
	
	
	String o;  // O IS THE OBJECT WHICH IS CREATING FOR EACH ROW IT STRORES 3 VALUES KEYWORD,XPATH,TESTDATA

	
	
	public static XSSFSheet set_sheet(String sheetname)
	{
		XSSFSheet sh=null;
		try {
			File f=new File(filename);
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			sh=wb.getSheet(sheetname);
		}

		catch (IOException e) {
			// TODO: handle exception
			
			e.printStackTrace();
		}
		return sh;
		
	}
	
	
	public static tc_selection read_TC_SELECTION_SH(int j)
	{
		tc_selection td=new tc_selection();
		try {
	
			 tc_sh_obj = set_sheet(tc_sheet);
			
			XSSFRow rw=tc_sh_obj.getRow(j);
			td.tcid=rw.getCell(0).getStringCellValue();
			td.flag=rw.getCell(1).getStringCellValue();
			td.no_steps=(int)rw.getCell(2).getNumericCellValue();
			td.test_data_sh=rw.getCell(3).getStringCellValue();
		}

		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}return td;	
	}
	

	public static keyword_sh read_kw_sh(int i) throws IOException{
		keyword_sh kw=new keyword_sh();
		
		kw_sh_obj=set_sheet(kw_sheet);
		
		XSSFRow rw=kw_sh_obj.getRow(i);
		kw.TC_ID=rw.getCell(0).getStringCellValue();
		kw.step_no=rw.getCell(1).getStringCellValue();
		kw.keyWord=rw.getCell(2).getStringCellValue();
		kw.XPath=rw.getCell(3).getStringCellValue();
		kw.Test_Data=rw.getCell(4).getStringCellValue();
		return kw;
		
	}
	
	
	
	
	
	public String read_excel(int row, int col) {
		try {
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\registerdemo.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("sheet1");

			XSSFRow r1 = sh.getRow(row);
			XSSFCell c1 = r1.getCell(col);
			o = c1.getStringCellValue();
			System.out.println("out:"+o);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return o;

	}


						//    WRITE FUNCTION FOR WRITING TESTRESULT
	
	
	public void write_excel(int row,int col,String v)
{
	try {
		File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\registerdemo.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		
XSSFRow r=sh.getRow(row);
		
XSSFCell c=	r.createCell(col);
System.out.println("after createCell");
c.setCellValue(v);
FileOutputStream fos=new FileOutputStream(f);
wb.write(fos);

		
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
	
	
	
	}
}
