package SDAY10;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import SDAY7.excel_operations;
public class all_webelement_fns1 {

	//public class pgm4{
	//WebDriver dr;							// alternate method working same
//	pgm4(WebDriver dr){
	//	this.dr=dr;
	
	WebDriver dr;
	public all_webelement_fns1(WebDriver dr) {
		// TODO Auto-generated constructor stub
		this.dr=dr;
	}
	
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
	
	
	public void enter_txt(String xp,String data) {
		//System.out.println(xp+"" +data);
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	public void click(String  xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void gender(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
		
	}
	public void close()
	{
		dr.close();
	}
	public void verify(String xp,String td,int row,excel_operations excel)
	{
		String str=dr.findElement(By.xpath(xp)).getText();
		System.out.println("str:"+str);
		System.out.println("td:"+td);
		
		if(str.equals(td)) {
			System.out.println("successful");
			excel.write_excel(row,6,"pass");
			}
		else
		{
			System.out.println("unsucessful");
			excel.write_excel(row,6,"fail");
		
		}}
	
}
