package SDAY7;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY7.pgm1;
import SDAY7.data;


public class NewTest3 {
	pgm1 p=new pgm1();
	data t;
	data t1;
	
  @Test
  public void test1() {
	  t=new data();
	  t1=new data();
	  t.uid="vasunarthu7@gmail.com";
	  t.password="vasu1234";
	  t.exp_res="success";
	  t1=p.login(t);
	
	SoftAssert sa=new SoftAssert();
	AssertJUnit.assertEquals(t.exp_res,t1.act_res );
	System.out.println("actualresult::"+t.act_res+" "+" testresult::"+t1.testresult+" ");
	sa.assertAll();
  }
  @Test
  public void test2() {
	  t=new data();
	  t1=new data();
	  t.uid="sourabhnegi356@gmail.com";
	  t.password="P@sswo";
	  t.exp_res="success";
	t1=p.login(t);
	SoftAssert sa=new SoftAssert();
	AssertJUnit.assertEquals(t.exp_res,t1.act_res );
	System.out.println("actualresult::"+t.act_res+" "+" testresult::"+t1.testresult+" ");
	sa.assertAll();
  }
  
}
