package SDAY7;

import org.openqa.selenium.WebDriver;

public class driverscript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String kw,loc,td;
		WebDriver dr=null;
		webelementfns we=new webelementfns(dr);
		excel_op excel=new excel_op();
		for(int r=1;r<=4;r++) {
			kw= excel.read_excel(r,3);
			loc=excel.read_excel(r,4);
			td=excel.read_excel(r,5);
			System.out.println(kw);
			System.out.println(loc);
			System.out.println(td);
			
			
			switch(kw)
			{
			case "launchchrome":
				we.launchChrome(td);
				break;
				
			case "enter_txt" :
				we.enter_txt(loc,td);
				break;
			
			case "click_btn" :
				we.click(loc);
				break;
			}
		}
		
	}

}
