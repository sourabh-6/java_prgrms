package SDAY7;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider {
	method mc;
	  String ar,er;
  @Test
  public void BC() {
	  
			mc=new method();  // calling constructor of method class.
  
  }
  
  @Test(dataProvider="security")
  public void test1(String s1,String s2,String s3,String s4,String s5){
	  
		  er=s3;
		  ar = mc.register(s1, s2, s3, s4, s5);  
		  
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ar, er);
	  System.out.println("Actual Result :  "+ar+ ", Expected Result :  "+er );
	  sa.assertAll();
  }
  
  
  @DataProvider(name="security")
  public String[][] provide_data() {
	  
	  String[][] daata = {{"abhay","negi",
		             "abhaynegi516@gmail.com","P@ssword6","P@ssword6"
	                 },
			  {
	                	 "Sourabh","negi",
			             "sourabhnegi186@gmail.com","password","password"	 
			  }
	               };
	  return daata;
  }
 
}
