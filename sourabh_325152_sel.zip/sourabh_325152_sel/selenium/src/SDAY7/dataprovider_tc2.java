package SDAY7;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataprovider_tc2 {
  @Test(dataProvider="security")
public void login(String u,String p)
{
	  System.out.println("login:  "+ u + " "+p);
	  } 

  
  @DataProvider(name="security")
public String[][] getdata()
{String[][] data= {{"uid1","233"},{"uid2","pwd2"}};

return data;
	}

}

