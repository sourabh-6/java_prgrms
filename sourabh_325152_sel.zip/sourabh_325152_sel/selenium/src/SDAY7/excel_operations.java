package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {

	String o;  // O IS THE OBJECT WHICH IS CREATING FOR EACH ROW IT STRORES 3 VALUES KEYWORD,XPATH,TESTDATA

	public String read_excel(int row, int col) {
		try {
			File f = new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\registerdemo.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("sheet1");

			XSSFRow r1 = sh.getRow(row);
			XSSFCell c1 = r1.getCell(col);
			o = c1.getStringCellValue();
			System.out.println("out:"+o);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return o;

	}


						//    WRITE FUNCTION FOR WRITING TESTRESULT
	
	
	public void write_excel(int row,int col,String v)
{
	try {
		File f=new File("C:\\Users\\sourabh.negi\\Desktop\\excel\\registerdemo.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		
XSSFRow r=sh.getRow(row);
		
XSSFCell c=	r.createCell(col);
System.out.println("after createCell");
c.setCellValue(v);
FileOutputStream fos=new FileOutputStream(f);
wb.write(fos);

		
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
	
	
	
	}
}
