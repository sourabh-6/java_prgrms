package SDAY7;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest5 {
	pgm2 pg=new pgm2();
	data t,t1;
	@BeforeClass
	public void a() {
		t=new data();
		t1=new data();
		
	}
	@Test(dataProvider="security")
	public void login(String u,String p,String r ) {
		t.uid=u;
		t.password=p;
		t.exp_res=r;
		t1=pg.login(t);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(t1.act_res, t.exp_res);
		sa.assertAll();
		
	}
	@DataProvider(name="security")
	public String[][] getdata(){
		String[][] d= {
				{"sourabhnegi356@gmail.com","P@ssword6","success"},
				{"sourabhnegi356@gmail.com","vdsjkfehfsd","failure"}
			
		};
		return d;
	}
}
