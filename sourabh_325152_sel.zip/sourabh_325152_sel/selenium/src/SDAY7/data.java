package SDAY7;

public class data {

	
	public String uid, password, exp_res,exp_em1,exp_em2,act_res,act_em1,act_em2,testresult;
	
	
		
}
