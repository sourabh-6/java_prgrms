package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelementfns {

	
	WebDriver dr;
	public webelementfns(WebDriver dr) {
		// TODO Auto-generated constructor stub
		this.dr=dr;
	}
	
	public void enter_txt(String xp,String data) {
		System.out.println(xp+"" +data);
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	public void click(String  xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
}
