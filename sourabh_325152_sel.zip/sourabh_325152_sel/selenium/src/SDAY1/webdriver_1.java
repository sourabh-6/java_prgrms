package SDAY1;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.interactions.ClickAction;

//import com.sun.org.apache.bcel.internal.generic.Select;

public class webdriver_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("https://www.facebook.com");
	
	 
	dr.findElement(By.id("email")).sendKeys("sourabhnegi356@gmail.com");
	dr.findElement(By.id("pass")).sendKeys("S0UR@BH06");	
	dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
	
	
	String s=dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
	if(s.compareTo("Sourabh")==0)
	{System.out.println("login successfulllllllllllllllllllllllllllll");
		
	}
	
	else
	{
		System.out.println("login uuuuuuuuuuuuuuuunsucessfulllllllllllllll");
	}
	

	

	}

}
