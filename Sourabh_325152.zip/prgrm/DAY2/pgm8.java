package DAY2;

public class pgm8 {

	public static void main(String[] args) {
int sum=0;
int a=15;
while(a<=75)
{
	if(a%7==0)
		{
		System.out.print( " "+a);
		sum=sum+a;}
	
		a++;
}
System.out.print("sum "+sum);
	}

}
