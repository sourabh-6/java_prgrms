package DAY2;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		 int c = 0; 
		 int n = 0; 
	    	
			while (c < 10) {
				n++; 
				if (n % 2 != 0) { 
				// check if the number is even
					if (is_Prime(n)) {
						sum += n; 					
					}
				}
	                    c++; 	
			}
			System.out.println("\nsum: "+sum); 	
	 }
	
  	public static boolean is_Prime(int n) {
		for (int i = 3; i * i <= n; i+= 2) {
			if (n % i == 0) {
				return false; 
			}
		}
		return true;
	}

}
