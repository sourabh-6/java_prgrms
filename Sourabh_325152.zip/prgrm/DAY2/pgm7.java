package DAY2;

import java.util.Scanner;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n;
int a=0;
Scanner s=new Scanner(System.in);
n=s.nextInt();
int r=n;
while(r>0)
{
	int x=r%10;
	r=r/10;
	if(x>5)
		a=a+x;
	}
System.out.println(" "+a);

	
}
	


	}
