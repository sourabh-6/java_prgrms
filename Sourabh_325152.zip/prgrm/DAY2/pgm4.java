package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=1;i<=5;i++)
	System.out.print(" "+i);
	}
	
}
