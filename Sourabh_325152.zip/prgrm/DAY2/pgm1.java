package DAY2;



public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int s=3;

	switch (s) { 
    case 1: 
        System.out.println("one");
        break; 
    case 2: 
    	 System.out.println("two"); 
        break; 
    case 3: 
    	 System.out.println("three");
        break; 
    case 4: 
    	 System.out.println("four");
        break; 
    case 5: 
    	 System.out.println("five");
        break; 
    case 6: 
    	 System.out.println("six");
        break; 
   
    default: 
    	 System.out.println("no match"); 
        break; 

	}
	 System.out.println("no output");
	}
	}

