package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		int s[]= {77,54,91,79,63,72};
		float avg;
		float sum=0;
for(int i=0;i<=5;i++)
{
	sum=sum+s[i];
	}
	
	avg=sum/6;
	System.out.println(avg);}

}
