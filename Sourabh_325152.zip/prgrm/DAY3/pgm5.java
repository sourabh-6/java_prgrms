package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks[][]= {{1,2,3,4},{5,6,7,8},{2,6,8,9}};
		int copy[];
		for(int r=0;r<=2;r++)	
		{System.out.print("max of "+r+" row is ");
			System.out.println(+maxarray(marks[r]));
			
		
		// print max of each row;
		}

	}

	public static int maxarray(int marks[]) {
		int k;
		int max =0;
		
		for( k=1;k<=3;k++)
		{max=marks[0];
			if(marks[k]>max)
			{
				max=marks[k];
				
			}
			
			
		}
			return max;
		// TODO Auto-generated method stub
	}

}
