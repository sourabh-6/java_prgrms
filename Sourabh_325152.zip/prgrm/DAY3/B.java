package DAY3;

public class B extends A {
int xyz;
public void show2()
{
	System.out.print(this.xyz);}
}
