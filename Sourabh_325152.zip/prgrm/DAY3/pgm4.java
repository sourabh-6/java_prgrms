package DAY3;

import org.omg.CORBA.SystemException;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int marks[][]=new int[2][3];
		int marks[][]= {{77,95,83},{65,92,79}};
		for(int r=0;r<=1;r++)
		{
			for(int c=0;c<=2;c++)
			{
				System.out.print(marks[r][c]+" ");
			}
			System.out.println("\n");
		}

	}

}
