package DAY3;

public class str1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="Noida",s2="Noida",s3="noida",s4="I am learning java";
int l=s1.length();
System.out.println("length :"+l);
int r=s1.compareTo(s3);
int r1=s1.compareToIgnoreCase(s3);
System.out.println(r1);
s3=s4.substring(3,8);
System.out.println(s3);
int n=s4.indexOf("a");
System.out.println(n);
n=s4.indexOf("a",3);
System.out.println(n);
	}
	

}
