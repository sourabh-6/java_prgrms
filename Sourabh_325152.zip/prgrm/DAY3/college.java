package DAY3;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
student rakesh=new student();
rakesh.rollno=73;
rakesh.name="rakesh";
rakesh.m1=83;
rakesh.m2=91;

student priya=new student();
priya.rollno=73;
priya.name="rakesh";
priya.m1=99;
priya.m2=91;


System.out.println(+rakesh.rollno);
System.out.println("name:"+rakesh.name);
System.out.println(+rakesh.m1);
System.out.println(+rakesh.m2);
	
rakesh.average();
System.out.println("average of rakesh is: "+rakesh.avg);

priya.average();
System.out.println("average of priya is:: "+priya.avg);}

}


