package DAY3;

public class str2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="I am learning java";
int c=0;
for(int i=0;i<s1.length();i++)
{
if(s1.charAt(i)==' ')
{c++;
}
}
System.out.println(c);
}

}
