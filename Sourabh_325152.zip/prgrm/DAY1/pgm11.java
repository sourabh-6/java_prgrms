package DAY1;

import java.util.Scanner;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, b, c;
		Scanner s = new Scanner(System.in);
		a = s.nextInt();
		b = s.nextInt();
		c = s.nextInt();
		if(a==b&&b==c)
		{	System.out.println("no are equall");
			
		}
int greatest=greatest(a,b,c);
int smallest=smallest(a,b,c);
System.out.println(" gretaest"+greatest);
System.out.println("smallest"+smallest);

		}
		

public static int greatest(int a,int b,int c)
{
int max=a;
if(b>max)
	max=b;
if(c>max)
	max=c;

return max;
}

public static int smallest(int a,int b,int c)
{	int min=a;
if(b<min)
	min=b;
if(c<min)
	min=c;
return min;
	}
}