package DAY1;

import java.util.Scanner;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
float a,b,c;
float avg;
Scanner s = new Scanner(System.in);
a = s.nextFloat();
b = s.nextFloat();
c = s.nextFloat();
avg=(a+b+c)/3;
System.out.println("average is: "+avg);
if(avg>=60)
	System.out.println("first grade");
else if(avg>=50&&avg<60)
	System.out.println("second grade");
else if(avg>=40&&avg<50)
	System.out.println("third grade");
else if(avg>=30&&avg<40)
	System.out.println("passing grade");
else
	System.out.println("fail grade");

	}

}
