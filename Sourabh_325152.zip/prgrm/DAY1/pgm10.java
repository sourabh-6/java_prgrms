package DAY1;

import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		/*Scanner s=new Scanner(System.in);
	char z=s.next().charAt(0);
*/
char z='a';
if(z=='a'||z=='e'||z=='i'||z=='o'||z=='u'||z=='A'||z=='e'||z=='i'||z=='o'||z=='u')
	System.out.println("char is vowel");
else
	System.out.println("char is not vowel");


	}

}
